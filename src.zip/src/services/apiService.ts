import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import customAuthService from './customAuthService';

class ApiService {
  private api: AxiosInstance;

  constructor() {
    this.api = axios.create({
      baseURL: 'http://localhost:8090/api/v1',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add request interceptor to include auth token
    this.api.interceptors.request.use(
      async (config) => {
        const token = customAuthService.getAccessToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Add response interceptor to handle auth errors
    this.api.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          // Token expired or invalid, redirect to login
          customAuthService.removeUser();
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // User API calls
  async getUsers() {
    const response = await this.api.get('/users');
    return response.data;
  }

  async getUser(id: string) {
    const response = await this.api.get(`/users/${id}`);
    return response.data;
  }

  async createUser(userData: any) {
    const response = await this.api.post('/users', userData);
    return response.data;
  }

  async updateUser(id: string, userData: any) {
    const response = await this.api.put(`/users/${id}`, userData);
    return response.data;
  }

  async deleteUser(id: string) {
    const response = await this.api.delete(`/users/${id}`);
    return response.data;
  }

  // Group API calls
  async getGroups() {
    const response = await this.api.get('/groups');
    return response.data;
  }

  async getGroup(id: string) {
    const response = await this.api.get(`/groups/${id}`);
    return response.data;
  }

  async createGroup(groupData: any) {
    const response = await this.api.post('/groups', groupData);
    return response.data;
  }

  async updateGroup(id: string, groupData: any) {
    const response = await this.api.put(`/groups/${id}`, groupData);
    return response.data;
  }

  async deleteGroup(id: string) {
    const response = await this.api.delete(`/groups/${id}`);
    return response.data;
  }

  // Organization API calls
  async getOrganizations() {
    const response = await this.api.get('/organizations');
    return response.data;
  }

  async getOrganization(id: string) {
    const response = await this.api.get(`/organizations/${id}`);
    return response.data;
  }

  async createOrganization(orgData: any) {
    const response = await this.api.post('/organizations', orgData);
    return response.data;
  }

  async updateOrganization(id: string, orgData: any) {
    const response = await this.api.put(`/organizations/${id}`, orgData);
    return response.data;
  }

  async deleteOrganization(id: string) {
    const response = await this.api.delete(`/organizations/${id}`);
    return response.data;
  }
}

export const apiService = new ApiService();
export default apiService; 